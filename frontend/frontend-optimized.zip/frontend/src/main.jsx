import React from 'react';
import ReactDOM from 'react-dom/client';
import './i18n.js';          // initialise i18next before rendering
import App from './App.jsx';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
